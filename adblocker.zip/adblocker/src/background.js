const DEFAULT_SETTINGS = {
  enabled: true,
  customBlockDomains: []
};

async function getSettings() {
  const data = await chrome.storage.sync.get(DEFAULT_SETTINGS);
  return {
    enabled: data.enabled !== false,
    customBlockDomains: Array.isArray(data.customBlockDomains) ? data.customBlockDomains : []
  };
}

function domainToRule(domain, id) {
  return {
    id,
    priority: 1,
    action: { type: "block" },
    condition: {
      urlFilter: `||${domain}^`,
      resourceTypes: [
        "main_frame",
        "sub_frame",
        "script",
        "xmlhttprequest",
        "image",
        "media",
        "other"
      ]
    }
  };
}

async function syncDynamicRules() {
  const settings = await getSettings();
  const existing = await chrome.declarativeNetRequest.getDynamicRules();
  const removeRuleIds = existing.map((rule) => rule.id);

  if (!settings.enabled) {
    await chrome.declarativeNetRequest.updateDynamicRules({
      removeRuleIds
    });
    return;
  }

  const sanitizedDomains = settings.customBlockDomains
    .map((domain) => domain.trim().toLowerCase())
    .filter(Boolean)
    .filter((domain) => !domain.includes(" "))
    .slice(0, 5000);

  const addRules = sanitizedDomains.map((domain, index) => domainToRule(domain, 10000 + index));

  await chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds,
    addRules
  });
}

async function initialize() {
  const settings = await chrome.storage.sync.get(DEFAULT_SETTINGS);
  if (typeof settings.enabled === "undefined" || !Array.isArray(settings.customBlockDomains)) {
    await chrome.storage.sync.set(DEFAULT_SETTINGS);
  }
  await syncDynamicRules();
}

chrome.runtime.onInstalled.addListener(() => {
  initialize().catch((error) => {
    console.error("Failed to initialize extension:", error);
  });
});

chrome.runtime.onStartup.addListener(() => {
  syncDynamicRules().catch((error) => {
    console.error("Failed to sync rules on startup:", error);
  });
});

chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName !== "sync") {
    return;
  }

  if (changes.enabled || changes.customBlockDomains) {
    syncDynamicRules().catch((error) => {
      console.error("Failed to sync dynamic rules:", error);
    });
  }
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "getStats") {
    chrome.declarativeNetRequest
      .getMatchedRules({ minTimeStamp: Date.now() - 24 * 60 * 60 * 1000 })
      .then((result) => {
        sendResponse({
          matchedRulesCount: result.rulesMatchedInfo.length
        });
      })
      .catch(() => {
        sendResponse({ matchedRulesCount: 0 });
      });
    return true;
  }

  return false;
});
