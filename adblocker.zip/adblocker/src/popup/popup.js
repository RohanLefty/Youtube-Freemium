const enabledToggle = document.getElementById("enabledToggle");
const blockedCount = document.getElementById("blockedCount");
const openOptions = document.getElementById("openOptions");

async function loadState() {
  const { enabled = true } = await chrome.storage.sync.get({ enabled: true });
  enabledToggle.checked = enabled;

  const stats = await chrome.runtime.sendMessage({ type: "getStats" });
  blockedCount.textContent = String(stats?.matchedRulesCount || 0);
}

enabledToggle.addEventListener("change", async () => {
  await chrome.storage.sync.set({ enabled: enabledToggle.checked });
});

openOptions.addEventListener("click", () => {
  chrome.runtime.openOptionsPage();
});

loadState().catch((error) => {
  console.error("Failed to load popup state:", error);
});
