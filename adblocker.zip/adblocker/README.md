# Universal Ad Blocker (Chrome Extension)

This is a Manifest V3 Chrome extension that blocks many common ad/tracker requests and applies cosmetic filtering for ad elements on pages, including YouTube.

## Features

- Blocks common ad network domains using `declarativeNetRequest`.
- Removes/hides ad containers with a content script.
- Attempts to auto-skip YouTube video ads when possible.
- Popup toggle to quickly enable/disable blocking.
- Options page for custom domain block rules (one per line).

## Install in Chrome

1. Open `chrome://extensions`.
2. Enable **Developer mode**.
3. Click **Load unpacked**.
4. Select this project folder (`adblocker`).

## Notes

- Ad blocking can never be perfect due to changing ad delivery patterns.
- Some websites may break if they depend on third-party scripts that are blocked.
- If a site breaks, disable the extension temporarily or adjust custom rules.
