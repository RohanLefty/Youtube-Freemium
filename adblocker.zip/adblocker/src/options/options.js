const textarea = document.getElementById("domains");
const saveBtn = document.getElementById("saveBtn");
const status = document.getElementById("status");

function normalizeDomains(rawValue) {
  return [...new Set(
    rawValue
      .split("\n")
      .map((line) => line.trim().toLowerCase())
      .filter(Boolean)
      .map((line) => line.replace(/^https?:\/\//, ""))
      .map((line) => line.replace(/\/.*$/, ""))
      .filter((line) => /^[a-z0-9.-]+$/.test(line))
  )];
}

async function loadDomains() {
  const { customBlockDomains = [] } = await chrome.storage.sync.get({ customBlockDomains: [] });
  textarea.value = customBlockDomains.join("\n");
}

saveBtn.addEventListener("click", async () => {
  const domains = normalizeDomains(textarea.value);
  await chrome.storage.sync.set({ customBlockDomains: domains });
  status.textContent = `Saved ${domains.length} domain rule(s).`;
});

loadDomains().catch((error) => {
  console.error("Failed to load domains:", error);
  status.textContent = "Could not load existing rules.";
});
