(() => {
  const HIDE_SELECTORS = [
    "iframe[src*='doubleclick.net']",
    "iframe[src*='googlesyndication.com']",
    "[id*='google_ads']",
    "[class*='ad-slot']",
    "[class*='advert']",
    "[data-ad-client]",
    ".adsbygoogle",
    ".ad-container",
    ".ad-banner"
  ];

  const YOUTUBE_AD_SELECTORS = [
    ".ytp-ad-module",
    ".ytp-ad-overlay-container",
    ".video-ads",
    "ytd-display-ad-renderer",
    "ytd-ad-slot-renderer",
    "ytd-promoted-sparkles-web-renderer"
  ];

  function hideMatchedElements(selectors) {
    for (const selector of selectors) {
      document.querySelectorAll(selector).forEach((node) => {
        node.style.setProperty("display", "none", "important");
        node.remove();
      });
    }
  }

  function skipYouTubeVideoAds() {
    if (!location.hostname.includes("youtube.com")) {
      return;
    }

    const player = document.querySelector("video");
    const adShowing = document.querySelector(".ad-showing");
    if (player && adShowing && Number.isFinite(player.duration)) {
      player.currentTime = player.duration;
    }

    const skipButton = document.querySelector(".ytp-ad-skip-button, .ytp-skip-ad-button");
    if (skipButton instanceof HTMLElement) {
      skipButton.click();
    }
  }

  function applyCosmeticBlocking() {
    hideMatchedElements(HIDE_SELECTORS);
    hideMatchedElements(YOUTUBE_AD_SELECTORS);
    skipYouTubeVideoAds();
  }

  const style = document.createElement("style");
  style.textContent = `
    ${HIDE_SELECTORS.concat(YOUTUBE_AD_SELECTORS).join(",\n")} {
      display: none !important;
      visibility: hidden !important;
      opacity: 0 !important;
      pointer-events: none !important;
    }
  `;
  document.documentElement.appendChild(style);

  applyCosmeticBlocking();
  setInterval(applyCosmeticBlocking, 1200);

  const observer = new MutationObserver(() => applyCosmeticBlocking());
  observer.observe(document.documentElement, {
    childList: true,
    subtree: true
  });
})();
